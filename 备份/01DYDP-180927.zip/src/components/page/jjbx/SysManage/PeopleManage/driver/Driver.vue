<!--   
    name：紧急避险角色管理
    desc：紧急避险主界面
    param：None        
    return Value : None
    author：qiaoyh
    date：2018.9.3
-->
<template>

    <div class="common-driver-body">
        <div class="common-driver-formbox">
            <div class="common-driver-handlebox">
                <form :model="ruleForm" ref="ruleForm">
                    车牌号： <input class="common-driver-input" placeholder="请输入" v-model="ruleForm.carnum">
                    所属企业： <input class="common-driver-input" placeholder="请输入" v-model="ruleForm.company">
                    所属机构： <select class="common-driver-select" v-model="ruleForm.orgname">
                                <option value="" >请选择</option>
                                <!-- <option value="saab">Saab</option>
                                <option value="opel">Opel</option>
                                <option value="audi">Audi</option> -->
                                <option v-for="item in selectOrg" :key="item.id"  :value="item.id">{{item.text}} 
                                </option>
                            </select>
                            <!-- <span>{{ruleForm.orgname}}</span> -->
                    车辆状态： <select  class="common-driver-select" v-model="ruleForm.carstates">
                                <option value="">请选择</option>
                                <!-- <option v-for="item in selectStatus" :key="item.value" :label="item" :value="item.value">
                                </option> -->
                                <option v-for="item in selectStatus" :key="item.id"  :value="item.id">{{item.text}}
                                </option>
                            </select>
                            <span>{{ruleForm.carstates}}</span>
                    <button type="button" class="button-info" @click="search();">查询</button>
                </form>
                
            </div>
        </div>
        <div class="common-driver-menu">
            <div class="el-button-text">
                <button type="button" class="button-info-2"><img src="../../../../../../../static/img/jjbx/vehicle/dc.png" class="img-3">导出</button>
                <button type="button" class="button-info-2" @click="add();"><img src="../../../../../../../static/img/jjbx/vehicle/tj.png" class="img-3">添加</button>
                <button type="button" class="button-info-2"><img src="../../../../../../../static/img/jjbx/vehicle/pl.png" class="img-3">批量设置百公里油耗</button>
                <button type="button" class="button-info-2"><img src="../../../../../../../static/img/jjbx/vehicle/xl.png" class="img-3">表格列设置</button>
                <!-- <el-button type="primary" plain size="small" style="width: 68px;height: 29px;line-height:10px;"><img src="../../../../../static/img/jjbx/vehicle/dc.png" class="img-3" > 导出</el-button>
                <el-button class="el-icon-plus" type="primary" plain size="small" style="width: 68px;height: 29px;">添加</el-button>
                <el-button type="primary" plain size="small" style="width: 150px;height: 29px;"><img src="../../../../../static/img/jjbx/vehicle/pl.png" class="img-3"> 批量设置百公里油耗</el-button>
                <el-button type="primary" plain size="small" style="width: 105px;height: 29px;"><img src="../../../../../static/img/jjbx/vehicle/xl.png" class="img-3"> 表格列设置</el-button> -->
            </div>
        </div>
        <div class="common-driver-table">
            <el-table :data="tableData" :highlight-current-row="true" :stripe="true" :header-cell-style="{background:'rgba(238,245,251,1)'}"
                height="calc( 100% - 70px )" :row-class-name="onSetRowIndex"
                @cell-mouse-enter="handleMouseEnter" @cell-mouse-leave="handleMouseOut" >
                <el-table-column fixed align="center" type="index" :index="indexMethod" label="序号" width="80">
                </el-table-column>  
                <el-table-column prop="name" align="center" label="详情" width="100">
                    <template slot-scope="scope">
                        <img v-if="scope.row.isSele" src="../../../../../../../static/img/jjbx/vehicle/xq.png" class="img-1">
                        <img v-if="!scope.row.isSele" src="../../../../../../../static/img/jjbx/vehicle/xq2.png" class="img-1">
                    </template>
                </el-table-column>
                <el-table-column prop="province" align="center" label="操作" width="100">
                    <template slot-scope="scope">
                        <img v-if="scope.row.isSele" src="../../../../../../../static/img/jjbx/vehicle/bj.png" class="img-1 img-2" @click="handleEdit(scope.$index, scope.row)">
                        <img v-if="!scope.row.isSele" src="../../../../../../../static/img/jjbx/vehicle/bj2.png"  class="img-1 img-2" @click="handleEdit(scope.$index, scope.row)">                         
                        <img v-if="scope.row.isSele" src="../../../../../../../static/img/jjbx/vehicle/sc.png" class="img-1">
                        <img v-if="!scope.row.isSele" src="../../../../../../../static/img/jjbx/vehicle/sc2.png" class="img-1">
                    </template>
                </el-table-column>
                <el-table-column prop="carNum" align="center" label="车牌号码" width="120" :show-overflow-tooltip="true"> {{tableData.carnum}}
                </el-table-column>
                <el-table-column prop="carOrgName" align="center" label="所属机构" width="150" :show-overflow-tooltip="true">
                </el-table-column>
                <el-table-column prop="carLength" align="center" label="车长" width="120">
                </el-table-column>
                <el-table-column prop="carCarriage" align="center" label="箱型" width="120">
                </el-table-column>
                <el-table-column prop="carVolume" align="center" label="额定体积" width="120">
                </el-table-column>
                <el-table-column prop="carWeight" align="center" label="额定载重" width="120">
                </el-table-column>
                <el-table-column prop="carStates" align="center" label="车辆状态" width="120">
                </el-table-column>
                <el-table-column prop="semiCarNum" align="center" label="挂车车牌号" width="120">
                </el-table-column>
                <el-table-column prop="fleetId" align="center" label="车队" width="120">
                </el-table-column>
                <el-table-column prop="carDriver1Id" align="center" label="第一司机" width="120">
                </el-table-column>
            </el-table>
            <!-- <div class="pagination">
                <el-pagination @current-change="handleCurrentChange" layout="prev, pager, next" :total="1000">
                </el-pagination>
            </div> -->
            <div class="pagination">
                <el-pagination @current-change="handleCurrentChange" layout="total, prev, pager, next" :total="totalElements">
                </el-pagination>
            </div>
        </div>
    </div>
</template>

<script>
import ajax from "axios";
    export default {
        data() {
            return {
                // ok:[],
                // multipleSelection: [],
                selectOrg: [],
                selectStatus: [],
                tableData: [{
                        date: "1",
                        isSele: false,
                        carDriver1Id: "王小虎",
                        fleetId: "上海",
                        carNum: "鲁F123",
                        carOrgName: "恒通集团",
                        carStates: "111"
                    },
                    {
                        date: "1",
                        isSele: false,
                        carDriver1Id: "王小虎",
                        fleetId: "上海",
                        carNum: "鲁F123",
                        carOrgName: "恒通集团",
                        carStates: "111"
                    },
                    {
                        date: "1",
                        isSele: false,
                        carDriver1Id: "王小虎",
                        fleetId: "上海",
                        carNum: "鲁F123",
                        carOrgName: "恒通集团",
                        carStates: "111"
                    },
                    {
                        date: "1",
                        isSele: false,
                        carDriver1Id: "王小虎",
                        fleetId: "上海",
                        carNum: "鲁F123",
                        carOrgName: "恒通集团",
                        carStates: "111"
                    },
                    {
                        date: "1",
                        isSele: false,
                        carDriver1Id: "王小虎",
                        fleetId: "上海",
                        carNum: "鲁F123",
                        carOrgName: "恒通集团",
                        carStates: "111"
                    },
                    {
                        date: "1",
                        isSele: false,
                        carDriver1Id: "王小虎",
                        fleetId: "上海",
                        carNum: "鲁F123",
                        carOrgName: "恒通集团",
                        carStates: "111"
                    },
                    {
                        date: "1",
                        isSele: false,
                        carDriver1Id: "王小虎",
                        fleetId: "上海",
                        carNum: "鲁F123",
                        carOrgName: "恒通集团",
                        carStates: "111"
                    },
                    {
                        date: "1",
                        isSele: false,
                        carDriver1Id: "王小虎",
                        fleetId: "上海",
                        carNum: "鲁F123",
                        carOrgName: "恒通集团",
                        carStates: "111"
                    },
                    {
                        date: "1",
                        isSele: false,
                        carDriver1Id: "王小虎",
                        fleetId: "上海",
                        carNum: "鲁F123",
                        carOrgName: "恒通集团",
                        carStates: "111"
                    },
                    {
                        date: "1",
                        isSele: false,
                        carDriver1Id: "王小虎",
                        fleetId: "上海",
                        carNum: "鲁F1e23",
                        carOrgName: "恒通集团",
                        carStates: "111"
                    },
                    {
                        date: "1",
                        isSele: false,
                        carDriver1Id: "王小虎",
                        fleetId: "上海",
                        carNum: "鲁F1d23",
                        carOrgName: "恒通集团",
                        carStates: "111"
                    },
                    {
                        date: "1",
                        isSele: false,
                        carDriver1Id: "王小虎",
                        fleetId: "上海",
                        carNum: "鲁Fc123",
                        carOrgName: "恒通集团",
                        carStates: "111"
                    },
                    {
                        date: "1",
                        isSele: false,
                        carDriver1Id: "王小虎",
                        fleetId: "上海",
                        carNum: "鲁F1b23",
                        carOrgName: "恒通集团",
                        carStates: "111"
                    },
                    {
                        date: "1",
                        isSele: false,
                        carDriver1Id: "王小虎",
                        fleetId: "上海",
                        carNum: "鲁F1a23",
                        carOrgName: "恒通集团",
                        carStates: "111"
                    },
                    {
                        date: "1",
                        isSele: false,
                        carDriver1Id: "王小虎",
                        fleetId: "上海",
                        carNum: "鲁F123",
                        carOrgName: "恒通集团",
                        carStates: "111"
                    },
                    {
                        date: "21",
                        isSele: false,
                        carDriver1Id: "王小虎",
                        fleetId: "上海",
                        city: "鲁F12a3",
                        carOrgName: "恒通集团",
                        carStates: "111"
                    }
                ],
                cur_page: 1,
                totalElements: 0, //总条数
                is_search:false,
                ruleForm: {
                    carnum: '',
                    company: '',
                    orgname: '',
                    carstates:''
                },
                idx: -1,
            };
        },
        // created() {
        //     let _this = this;
        //    this.search();
        //    this.getOrg();
        //    this.getStatus();
        // },
        methods: {
            // 分页导航
            // handleCurrentChange(val) {
            //     let _this = this;
            //     this.cur_page = val;
            //     this.getData();
            // },
            /**
             * @function {获取下一行}
             * @param  {number} index {行索引}
             * @return {number} {下一行索引}
             */
            indexMethod(index) {
                return index + 1;
            },
            onSetRowIndex({
                row,
                rowIndex
            }) {
                //把每一行的索引放进row 
                row.index = rowIndex;
            },
            /**
             * @function {鼠标 hover 进入时触发事件}
             * @param  {string} row    {行}
             * @param  {object} event  {description}
             * @param  {string} column {列}
             * @return {type} {description}
             */
            handleMouseEnter: function (row, event, column) {
                var index = row.index;
                this.tableData[row.index].isSele = true;
            },
            /**
             * @function {鼠标 hover 退出时触发事件}
             * @param  {type} row    {行}
             * @param  {type} event  {description}
             * @param  {type} column {列}
             * @return {type} {description}
             */
            handleMouseOut: function (row, event, column) {
                this.tableData[row.index].isSele = false;
            },
            /**
             * @function {function name}
             * @param  {type} formName {currentPage,pageSize}
            //  * @return {type} {车辆列表 , 总数}
             */
            // getData(){
            //     let _this = this;
            //     var data = [];
            //     let  param = {
            //             carNum: _this.ruleForm.carnum,
            //             companyName: _this.ruleForm.company,
            //             carOrgName: _this.ruleForm.orgname,
            //             carStates: _this.ruleForm.carstates
            //     };
            //     console.log(param);
            //     ajax.get(_this.global_.apiUrlJj + "/get/car?currentPage="+this.cur_page+"&pageSize=13" ,{params:param}
            //     // , 
            //     // param 
            //     ).then(function (res) {
            //             console.log(res);
            //             for (let i = 0; i < res.data.data.content.length; i++) {
            //                 var obj = {}
            //                 obj.carNum = res.data.data.content[i].carNum
            //                 obj.carOrgName = res.data.data.content[i].carOrgName
            //                 obj.carLength = res.data.data.content[i].carLength
            //                 obj.carCarriage = res.data.data.content[i].carCarriage
            //                 obj.carDriver1Id = res.data.data.content[i].carDriver1Id
            //                 obj.carStates = res.data.data.content[i].carStates
            //                 obj.carVolume = res.data.data.content[i].carVolume
            //                 obj.carWeight = res.data.data.content[i].carWeight
            //                 obj.fleetId = res.data.data.content[i].fleetId
            //                 obj.semiCarNum = res.data.data.content[i].semiCarNum
            //                 obj.isSele = res.data.data.content[i].isSele;
            //                 data[i] = obj
            //             }
            //             _this.tableData = data;
            //             _this.totalElements = res.data.data.totalElements;
            //             console.log(_this.tableData);
            //     })
            //     .catch(function (error) {
            //             console.log(error);
            //     }); 
            // },
            /**
             * @function {获取所属机构信息}
             * @return {string} {机构名称}
             */
            // getOrg(){
            //     let _this = this;
            //     ajax.get(_this.global_.apiUrlJj + "/get/car-org-name" )
            //     .then(function(res){
            //         console.log(res);
            //         // var obj = {}
            //         if(res.data){
            //             if(res.data.data){
            //                 res.data.data.forEach((item,index) => {
            //                     _this.selectOrg.push({id:item.car_org_code,text:item.car_org_name});       
            //                 });
            //             }
            //         } 
            //     });
            // },
            // getStatus(){
            //     let _this = this;
            //     ajax.get(_this.global_.apiUrlJj + "/get/car-states" )
            //     .then(function(res){
            //         console.log(res);
            //         // var obj = {}
            //         if(res.data){
            //             if(res.data.data){
            //                 res.data.data.forEach((item,index) => {
            //                     _this.selectStatus.push({id:index,text:item});       
            //                 });
            //             }
            //         }
            //         // _this.selectStatus = res.data.data;
            //     });
            // },
            // search(){
            //     let _this = this; 
            //     _this.getData();
            // },
            // handleEdit(){
                
            // },
            add(){
                let _this = this; 
                _this.$router.push("/carEdit");
                
            }
        }
    };
</script>
<style>
    /* 设置滚动条的样式 */
     scrollbar-base-color{
        width: 5px; 
        
        background: #E7EAEE
    }
 
    /* 表格整体布局 */
    .common-driver-table{
		/*scrollbar-arrow-color: #f4ae21; *//*三角箭头的颜色*/ 
		 /*scrollbar-face-color: #333;*//*立体滚动条的颜色*/ 
		/*scrollbar-3dlight-color: #666; *//*立体滚动条亮边的颜色*/ 
		/*scrollbar-highlight-color: #666; *//*滚动条空白部分的颜色*/ 
		/*scrollbar-shadow-color: #999; *//*立体滚动条阴影的颜色*/ 
		/*scrollbar-darkshadow-color: #666; *//*立体滚动条强阴影的颜色*/ 
		/*scrollbar-track-color: #666; *//*立体滚动条背景颜色*/ 
		/*scrollbar-base-color:#f8f8f8; *//*滚动条的基本颜色*/ 
        width:98%;height:calc( 100% - 110px );
	}
    /*定义滚动条的轨道颜色、内阴影及圆角*/
    .common-driver-table ::-webkit-scrollbar-track { 
        background-color: #E7EAEE; 
    }

    /*定义滑块颜色、内阴影及圆角*/
    .common-driver-table ::-webkit-scrollbar-thumb {
        border-radius: 17px;
        -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, .3);
        background-color: #fff;
    }

    /*定义两端按钮的样式*/
    .common-driver-table ::-webkit-scrollbar-button {
        background-color: #E7EAEE;
    }

    /*定义右下角汇合处的样式*/
    .common-driver-table ::-webkit-scrollbar-corner {
        background:#E7EAEE;
    }

    /* 整体布局 */
    .common-driver-body{
        margin-left:10px;margin-top:8px;height:calc( 100% - 96px );
    }
    /* 表单整体背景 */
    .common-driver-formbox{
        width:100%;
        background-color:#F8F8F8;
    }
    /* .demo-form-inline{padding-top:0.5%;} */
    /* .el-select{width: 60%} */
    
    /* 操作按钮整体布局 */
    .common-driver-menu{height:50px;width:99.2%;background-color:#FFFFFF;border:none;}
    /* 按钮左对齐 */
    .el-button--primary.is-plain{width: 68px;height: 32px; float: left;background: #2F95F4;color: #fff;}
    .common-driver-menu .el-button-text{ 
        width:422px;
        float:right;
        margin-top:10px;
        /* margin-left: 1400px; */
        font-size: 12px;
        }
    .common-driver-menu .el-button-text button:nth-of-type(1),button:nth-of-type(2){
        width: 73px;
    }
    .common-driver-menu .el-button-text button:nth-of-type(3){
        width: 150px;
    }
    .common-driver-menu .el-button-text button:nth-of-type(4){
        width: 105px;
    }
    /* 按钮图标设置 */
    .common-driver-menu .el-button-text .img-3{display:inline-block;width:13px;height:12px;margin-right: 5px;position: relative;top: 1px;}
    .common-driver-body .el-table__body {
        /* margin-top: 10px; */
        border-radius: 4px !important;
    }

    .common-driver-body .el-table__body tr {
        height: 35px !important;
    }
    .common-driver-table .el-table{width: 100%;border:1px solid rgba(237,241,245,1);}
    .common-driver-body .el-table td,
    .el-table th {
        padding: 2px !important;
    }

    .common-driver-body .icon {
        width: 2em !important;
        height: 2em !important;
        color: #5eaee3 !important;
    }

    .common-driver-body .common-driver-handlebox {
        /* margin-bottom: 20px; */
        width: 96.8% !important;
        height: 50px !important;
        line-height: 50px !important;
        padding-left: 1.2% !important;
        font-size: 12px !important;
        color: #5A5E66;
    }
    .common-driver-handlebox .common-driver-input{
        height:25px;width:133px;color:#B4BCCC;border-radius:4px;border: 1px solid;margin-right:12px;font-size:12px;
    }
    .common-driver-handlebox .common-driver-select{
        height:28px;width:133px;color:#B4BCCC;border-radius:4px;margin-right:12px;font-size:12px;
    }
    .common-driver-body .handle-select {
        width: 8.4% !important;
        height: 32px !important;
        margin: 0 8px !important;
    }

    .common-driver-body .handle-input {
        width: 280px !important;
        display: inline-block !important;
    }

    .common-driver-body .el-input--small .el-input__inner {
        height: 32px !important;
        line-height: 32px !important;
    }

    .common-driver-body .el-input__inner {
        box-shadow: 0px 0px 6px 0px rgba(25, 107, 255, 0.1) !important;
    }

    .common-driver-body .el-input--suffix .el-input__inner {
        padding-right: 10px !important;
    }

    .common-driver-body .el-table  { 
        color: #909090 !important;
    }
    .common-driver-body .el-table th>.cell {
        font-size: 14px !important;
        font-family: PingFang-SC-Medium !important;
        font-weight: 700 !important;
        color: rgba(30, 30, 30, 1) !important;
    }

    .common-driver-body .el-table .cell {
        font-size: 12px !important;
        font-family: PingFang-SC-Bold !important;   
    }

    .common-driver-body .el-table__body tr.hover-row>td {
        background: #2f95f4 !important;
        color: #fff;
    }

    .common-driver-body .el-table--striped .el-table__body tr.el-table__row--striped td {
        background: #f6f8f9;
    }
    .common-driver-table .img-1{width:11px;height:15px;vertical-align: middle;}
    .common-driver-table .img-2{margin-right:14px;}
    /* 查询按钮 */
    .common-driver-handlebox .button-info{
        display: inline-block;
        width: 68px;
        height: 29px;
        background-color: #2F95F4;
        color: #fff;
        border: 1px solid;
        border-radius: 4px;
        float: right;
        margin-top: 10px;
    }
    .common-driver-menu .button-info-2{
        display: inline-block;height: 29px;background-color: #2F95F4;color: #fff;border: 1px solid;border-radius: 4px;
    }
    
</style>
