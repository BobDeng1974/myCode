<!--   
    name：紧急避险司机管理添加页面
    desc：紧急避险二级界面
    param：None        
    return Value : None
    author：qiaoyh
    date：2018.9.11
-->
<template>
<div style="background-color:#EEEEEE;padding-top:12px;">
    <div style="width:1198px;border:1px solid #E2E1E1;box-shadow: 0px 0px 6px 0px rgba(25, 107, 255, 0.1);margin:0px auto;">
        <!-- 司机详细信息 -->
        <div style="height:48px; background-color:#F6F6F6;padding:0px 20px;border-bottom: 1px solid #e7e7e7;">
            <div style="float:left;line-height:48px;">
                <img>
                <span style="font-size: 16px;font-weight: 600;font-family: Microsoft YaHei;">添加司机信息</span>
            </div>
            
        </div>
        <!-- 管理信息 -->
        <div style="width:1198px;border-top:1px solid #E4E4E4;border-bottom:1px solid #E4E4E4; box-shadow:0px 0px 8px 0px rgba(47,149,244,0.16);">
            <div style="width:1179px;height:38px;line-height:38px;padding-left:20px;font-size:14px;font-family:PingFang-SC-Bold;font-weight:bold;color:rgba(30,30,30,1);"><img>司机基本信息</div>
            <div style="width:100%;height:400px;background-color:#fff;">
                
                <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm" size="mini">
                    <el-row>
                    <el-col span="12">
                    <el-form-item label="活动名称" prop="name">
                        <el-input v-model="ruleForm.name"></el-input>
                    </el-form-item>
                    </el-col>
                    <el-col span="12">
                    <el-form-item label="性别" prop="name">
                        <template>
                            <el-radio v-model="radio" label="1">男</el-radio>
                            <el-radio v-model="radio" label="2">女</el-radio>
                        </template>
                    </el-form-item>
                    </el-col>
                    </el-row>
                    <el-col span="12">
                    <el-form-item label="活动区域" prop="region">
                        <el-select v-model="ruleForm.region" placeholder="请选择活动区域">
                        <el-option label="区域一" value="shanghai"></el-option>
                        <el-option label="区域二" value="beijing"></el-option>
                        </el-select>
                    </el-form-item>
                    </el-col>
                    <el-col span="12">
                    <el-form-item label="出生日期" required>
                        
                        <el-form-item prop="date1">
                            <el-date-picker type="date" placeholder="选择日期" v-model="ruleForm.date1"></el-date-picker>
                        </el-form-item>
                        
                        
                    </el-form-item>
                    </el-col>
                    <el-form-item label="即时配送" prop="delivery">
                        <el-switch v-model="ruleForm.delivery"></el-switch>
                    </el-form-item>
                    <el-form-item label="活动性质" prop="type">
                        <el-checkbox-group v-model="ruleForm.type">
                        <el-checkbox label="美食/餐厅线上活动" name="type"></el-checkbox>
                        <el-checkbox label="地推活动" name="type"></el-checkbox>
                        <el-checkbox label="线下主题活动" name="type"></el-checkbox>
                        <el-checkbox label="单纯品牌曝光" name="type"></el-checkbox>
                        </el-checkbox-group>
                    </el-form-item>
                    <el-form-item label="特殊资源" prop="resource">
                        <el-radio-group v-model="ruleForm.resource">
                        <el-radio label="线上品牌商赞助"></el-radio>
                        <el-radio label="线下场地免费"></el-radio>
                        </el-radio-group>
                    </el-form-item>
                    <el-form-item label="活动形式" prop="desc">
                        <el-input type="textarea" v-model="ruleForm.desc"></el-input>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="primary" @click="submitForm('ruleForm')">保存</el-button>
                        <el-button @click="resetForm('ruleForm')">重置</el-button>
                    </el-form-item>
                </el-form>
                
            </div>

            <div style="width:1179px;height:38px;line-height:38px;padding-left:20px;font-size:14px;font-family:PingFang-SC-Bold;font-weight:bold;color:rgba(30,30,30,1);"><img>驾驶证信息</div>
            <div style="width:100%;height:160px;background-color:#fff;">
                <table>
                    <tr>
                        <td>系统车牌：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                        <td>定位类型：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>系统车牌：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                        <td>定位类型：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                    </tr>
                </table>
                
            </div>
            <div style="width:1179px;height:38px;line-height:38px;padding-left:20px;font-size:14px;font-family:PingFang-SC-Bold;font-weight:bold;color:rgba(30,30,30,1);"><img>司机账户信息</div>
            <div style="width:100%;height:160px;background-color:#fff;">
                <table>
                    <tr>
                        <td>系统车牌：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                        <td>定位类型：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>系统车牌：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                        <td>定位类型：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                    </tr>
                </table>
                
            </div>
        </div>
    </div>
</div>
</template>
<script>
  export default {
    data() {
      return {
        ruleForm: {
          name: '',
          region: '',
          date1: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        },
        radio: '1',
        rules: {
          name: [
            { required: true, message: '请输入活动名称', trigger: 'blur' },
            { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
          ],
          region: [
            { required: true, message: '请选择活动区域', trigger: 'change' }
          ],
          date1: [
            { type: 'date', required: true, message: '请选择日期', trigger: 'change' }
          ],
          date2: [
            { type: 'date', required: true, message: '请选择时间', trigger: 'change' }
          ],
          type: [
            { type: 'array', required: true, message: '请至少选择一个活动性质', trigger: 'change' }
          ],
          resource: [
            { required: true, message: '请选择活动资源', trigger: 'change' }
          ],
          desc: [
            { required: true, message: '请填写活动形式', trigger: 'blur' }
          ]
        }
      };
    },
    methods: {
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            alert('submit!');
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      },
      resetForm(formName) {
        this.$refs[formName].resetFields();
      }
    }
  }
</script>
<style>
    .el-input__inner{
        width: 30;
    }
</style>
