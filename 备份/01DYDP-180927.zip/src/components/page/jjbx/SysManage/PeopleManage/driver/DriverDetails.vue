<!--   
    name：紧急避险司机管理详情页面
    desc：紧急避险二级界面
    param：None        
    return Value : None
    author：qiaoyh
    date：2018.9.11
-->
<template>
<div style="background-color:#EEEEEE;padding-top:12px;">
    <div style="width:1198px;border:1px solid #E2E1E1;box-shadow: 0px 0px 6px 0px rgba(25, 107, 255, 0.1);margin:0px auto;">
        <!-- 司机详细信息 -->
        <div style="height:48px; background-color:#F6F6F6;padding:0px 20px;border-bottom: 1px solid #e7e7e7;">
            <div style="float:left;line-height:48px;">
                <img>
                <span style="font-size: 16px;font-weight: 600;font-family: Microsoft YaHei;">司机详细信息</span>
            </div>
            
        </div>
        <!-- 管理信息 -->
        <div style="width:1198px;border-top:1px solid #E4E4E4;border-bottom:1px solid #E4E4E4; box-shadow:0px 0px 8px 0px rgba(47,149,244,0.16);">
            <div style="width:1179px;height:38px;line-height:38px;padding-left:20px;font-size:14px;font-family:PingFang-SC-Bold;font-weight:bold;color:rgba(30,30,30,1);"><img>司机基本信息</div>
            <div style="width:100%;height:160px;background-color:#fff;">
                <table>
                    <tr>
                        <td>系统车牌：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                        <td>定位类型：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>系统车牌：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                        <td>定位类型：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                    </tr>
                </table>
                
            </div>

            <div style="width:1179px;height:38px;line-height:38px;padding-left:20px;font-size:14px;font-family:PingFang-SC-Bold;font-weight:bold;color:rgba(30,30,30,1);"><img>驾驶证信息</div>
            <div style="width:100%;height:160px;background-color:#fff;">
                <table>
                    <tr>
                        <td>系统车牌：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                        <td>定位类型：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>系统车牌：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                        <td>定位类型：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                    </tr>
                </table>
                
            </div>
            <div style="width:1179px;height:38px;line-height:38px;padding-left:20px;font-size:14px;font-family:PingFang-SC-Bold;font-weight:bold;color:rgba(30,30,30,1);"><img>司机账户信息</div>
            <div style="width:100%;height:160px;background-color:#fff;">
                <table>
                    <tr>
                        <td>系统车牌：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                        <td>定位类型：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>系统车牌：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                        <td>定位类型：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                    </tr>
                </table>
                
            </div>
        </div>
    </div>
</div>
</template>
<style>
    table{
        padding-top:1%;
    }
    td{
        /* border: 1px solid #E2E1E1; */
        padding: 10px 5px;    
    }
    td:nth-child(odd){
        width: 140px;
        text-align: right;
        color:#888;
    }
    td:nth-child(even){
        width: 160px;
    }
</style>
