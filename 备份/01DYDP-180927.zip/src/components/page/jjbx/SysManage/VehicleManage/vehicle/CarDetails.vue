<!--   
    name：紧急避险车辆管理详情页面
    desc：紧急避险二级界面
    param：None        
    return Value : None
    author：qiaoyh
    date：2018.9.10
-->
<template>
<div style="background-color:#EEEEEE;padding-top:12px;">
    <div style="width:1198px;border:1px solid #E2E1E1;box-shadow: 0px 0px 6px 0px rgba(25, 107, 255, 0.1);margin:0px auto;">
        <!-- 车牌信息 -->
        <div style="height:70px; background-color:#F6F6F6;padding:0px 20px;border-bottom: 1px solid #e7e7e7;">
            <div style="float:left;line-height:70px;">
                <img>
                <span style="font-size: 18px;font-weight: 600;font-family: Microsoft YaHei;">鲁F18747</span>
            </div>
            <div style="float:right;margin-top:24px;">
                <div style="float:left;background-color:#A0ADC0;width:31px;height:31px;margin-left:10px;"><img></div>
                <div style="float:left;background-color:#A0ADC0;width:31px;height:31px;margin-left:10px;"><img></div>
                <div style="float:left;background-color:#A0ADC0;width:31px;height:31px;margin-left:10px;"><img></div>
            </div>
        </div>
        <!-- <div style="width:100%;height:600px;background-color:#fff;"> -->
        <!-- 左侧报警提醒 -->
            <!-- <div style="float:left;padding-top: 20px;width: 860px; height:571px;">
                <div style="margin: 0 0 40px 20px;"></div>
            </div> -->
            <!-- 右侧状态 -->
            <!-- <div style="margin-right: 20px;float: right; width: 300px;height:596px; "></div>
        </div> -->
        <!-- 管理信息 -->
        <div style="width:1198px;border-top:1px solid #E4E4E4;border-bottom:1px solid #E4E4E4; box-shadow:0px 0px 8px 0px rgba(47,149,244,0.16);">
            <div style="width:1179px;height:38px;line-height:38px;padding-left:20px;font-size:14px;font-family:PingFang-SC-Bold;font-weight:bold;color:rgba(30,30,30,1);"><img>管理信息</div>
            <div style="width:100%;height:160px;background-color:#fff;">
                <table>
                    <tr>
                        <td>系统车牌：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                        <td>定位类型：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>系统车牌：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                        <td>定位类型：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                    </tr>
                </table>
                
            </div>

            <div style="width:1179px;height:38px;line-height:38px;padding-left:20px;font-size:14px;font-family:PingFang-SC-Bold;font-weight:bold;color:rgba(30,30,30,1);"><img>运营信息</div>
            <div style="width:100%;height:160px;background-color:#fff;">
                <table>
                    <tr>
                        <td>系统车牌：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                        <td>定位类型：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>系统车牌：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                        <td>定位类型：</td>
                        <td></td>
                        <td>自定义车牌：</td>
                        <td></td>
                    </tr>
                </table>
                
            </div>
        </div>
    </div>
</div>
</template>
<style>
    table{
        padding-top:1%;
    }
    td{
        /* border: 1px solid #E2E1E1; */
        padding: 10px 5px;    
    }
    td:nth-child(odd){
        width: 140px;
        text-align: right;
        color:#888;
    }
    td:nth-child(even){
        width: 160px;
    }
</style>
