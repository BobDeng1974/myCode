<!--   
    name：紧急避险车辆管理编辑页面
    desc：紧急避险二级界面
    param：None        
    return Value : None
    author：qiaoyh
    date：2018.9.5
-->
<template>
    <div style="width:1200px;height:800px;margin:50px auto;">
        <div style="width:1180px;height:48px;line-height:48px;padding-left:20px;background-color:#F8F8F8;">
            <div style="float:left;height:48px;line-height:48px;">
                <span style="font-size:16px;">修改车辆信息 </span>
                <span style="font-size:12px;color:#999999">“<span style="color:red;"> * </span>”为必填项</span>
            </div>
            <div style="float:right;font-size:14px;height:48px;line-height:48px;margin-right:20px;"><a href="#">车辆信息</a><span style="color:#999999"> > 修改车辆信息</span></div>
        </div>
        <div style="width:1198px;height:98px;line-height:98px;border:1px solid #E4E4E4;background-color:#fff;box-shadow:0px 0px 8px 0px rgba(47,149,244,0.16);">
            <div style="width:1160px;height:56px;line-height:56px;border:1px dashed #CCCCCC;text-align:center;margin-left:20px;margin-top:18px;background-color:#F8F8F8;">
                <img>
                <span style="font-size:14px;color:#999999;">车辆信息自动识别</span>
            </div>
        </div>
        <div style="width:1198px;border:1px solid #E4E4E4;margin-top:10px;box-shadow:0px 0px 8px 0px rgba(47,149,244,0.16);">
            <div style="width:1179px;height:38px;line-height:38px;padding-left:19px;font-size:14px;font-family:PingFang-SC-Bold;font-weight:bold;color:rgba(30,30,30,1);"><img>管理信息</div>
            <div class="common-caredit-form" style="width:100%;height:160px;background-color:#fff;">
                <!-- <el-form :inline="true" :model="formInline" :rules="rules" class="demo-form-inline" size="mini" style="padding-top:1%;">
                    <el-form-item label="云通智安"  prop="name1" style="margin-right:-34px;">
                        <el-input v-model="ruleForm.name" style="width:65%;"></el-input>
                    </el-form-item>
                    <el-form-item label="活动区域" prop="name2" style="margin-right:-40px;">
                        <el-select v-model="formInline.region" placeholder="活动区域" style="width:60%;">
                        <el-option label="区域一" value="shanghai"></el-option>
                        <el-option label="区域二" value="beijing"></el-option>
                        </el-select>
                    </el-form-item>
                </el-form> -->
                <form :model="ruleForm" ref="ruleForm" style="padding-left:1%;">
                    <table style="width:100%;background-color:yellow;">
                        <tr style="height:40px;line-height:40px;">
                            <td style="width:8%;line-height:28px;">车牌号码：</td>
                            <td style="width:15%;line-height:28px;"> <input class="sys-common-input" placeholder="请输入" v-model="ruleForm.carnum"></td>
                            <td style="width:8%;">车牌颜色：</td>
                            <td style="width:15%;"><input class="sys-common-input" placeholder="请输入" v-model="ruleForm.carnum"></td>
                            <td style="width:8%;">车辆颜色：</td>
                            <td style="width:15%;"><input class="sys-common-input" placeholder="请输入" v-model="ruleForm.company"></td>
                            <td style="width:8%;">车辆识别码：</td>
                            <td style="width:15%;"><input class="sys-common-input" placeholder="请输入" v-model="ruleForm.company"></td>
                        </tr>
                        <tr style="height:40px;line-height:40px;">
                            <td style="width:8%;line-height:28px;">发动机号：</td>
                            <td style="width:15%;line-height:28px;">  <input class="sys-common-input" placeholder="请输入" v-model="ruleForm.company"></td>
                            <td style="width:8%;">车辆类型：</td>
                            <td style="width:15%;">
                                <select class="sys-common-select" v-model="ruleForm.orgname">
                                    <option value="" >请选择</option>
                                    <option v-for="item in selectOrg" :key="item.id"  :value="item.id">{{item.text}} </option>
                                </select>
                            </td>
                            <td style="width:8%;">车辆状态：</td>
                            <td style="width:15%;">
                                <select  class="sys-common-select" v-model="ruleForm.carstates">
                                    <option value="">请选择</option>
                                    <option v-for="item in selectStatus" :key="item.id"  :value="item.id">{{item.text}}</option>
                                </select>  
                            </td>
                            <td style="width:8%;">强制报废期：</td>
                            <td style="width:15%;"><input class="sys-common-input" placeholder="请输入" v-model="ruleForm.company"></td>
                        </tr>
                    </table>
                      
                </form>
            </div>

            <div style="width:1179px;height:38px;line-height:38px;padding-left:19px;font-size:14px;font-family:PingFang-SC-Bold;font-weight:bold;color:rgba(30,30,30,1);"><img>运营信息</div>
            <div style="width:100%;height:160px;background-color:#fff;">
                <form :model="ruleForm" ref="ruleForm" style="padding-left:1%;">
                    <table style="width:100%;background-color:yellow;">
                        <tr style="height:40px;line-height:40px;">
                            <td style="width:8%;line-height:28px;">经营范围：</td>
                            <td style="width:15%;line-height:28px;"> <input class="sys-common-input" placeholder="请输入" v-model="ruleForm.carnum"></td>
                            <td style="width:8%;">交强险有效期：</td>
                            <td style="width:15%;"><input class="sys-common-input" placeholder="请输入" v-model="ruleForm.carnum"></td>
                            <td style="width:8%;">商业保险有效期：</td>
                            <td style="width:15%;"><input class="sys-common-input" placeholder="请输入" v-model="ruleForm.company"></td>
                            <td style="width:8%;">挂车车牌号：</td>
                            <td style="width:15%;">
                                <select class="sys-common-select" v-model="ruleForm.orgname">
                                    <option value="" >请选择</option>
                                    <option v-for="item in selectOrg" :key="item.id"  :value="item.id">{{item.text}} </option>
                                </select>
                            </td>
                        </tr>
                        <tr style="height:40px;line-height:40px;">
                            <td style="width:8%;line-height:28px;">车长：</td>
                            <td style="width:15%;line-height:28px;">  <input class="sys-common-input" placeholder="请输入" v-model="ruleForm.company"></td>
                            <td style="width:8%;">车宽：</td>
                            <td style="width:15%;"><input class="sys-common-input" placeholder="请输入" v-model="ruleForm.company"></td>
                            <td style="width:8%;">所属机构：</td>
                            <td style="width:15%;">
                                <select class="sys-common-select" v-model="ruleForm.orgname">
                                    <option value="" >请选择</option>
                                    <option v-for="item in selectOrg" :key="item.id"  :value="item.id">{{item.text}} </option>
                                </select>
                            </td>
                            <td style="width:8%;">所属机构代码：</td>
                            <td style="width:15%;">
                                <select  class="sys-common-select" v-model="ruleForm.carstates">
                                    <option value="">请选择</option>
                                    <option v-for="item in selectStatus" :key="item.id"  :value="item.id">{{item.text}}</option>
                                </select>  
                            </td>
                            
                        </tr>
                    </table>
                      
                </form>
                
                
            </div>
            <div style="width:1179px;height:38px;line-height:38px;padding-left:19px;font-size:14px;font-family:PingFang-SC-Bold;font-weight:bold;color:rgba(30,30,30,1);"><img>运营信息</div>
            <div style="width:100%;height:160px;background-color:#fff;">
                <form :model="ruleForm" ref="ruleForm" style="padding-left:1%;">
                    <table style="width:100%;background-color:yellow;">
                        <tr style="height:40px;line-height:40px;">
                            <td style="width:8%;line-height:28px;">车高：</td>
                            <td style="width:15%;line-height:28px;"> <input class="sys-common-input" placeholder="请输入" v-model="ruleForm.carnum"></td>
                            <td style="width:8%;">箱型：</td>
                            <td style="width:15%;"><input class="sys-common-input" placeholder="请输入" v-model="ruleForm.carnum"></td>
                            <td style="width:8%;">额定体积：</td>
                            <td style="width:15%;"><input class="sys-common-input" placeholder="请输入" v-model="ruleForm.company"></td>
                            <td style="width:8%;">额定载重：</td>
                            <td style="width:15%;"><input class="sys-common-input" placeholder="请输入" v-model="ruleForm.company"></td>
                        </tr>
                        <tr style="height:40px;line-height:40px;">
                            <td style="width:8%;line-height:28px;">本车百公里参考油耗：</td>
                            <td style="width:15%;line-height:28px;">  <input class="sys-common-input" placeholder="请输入" v-model="ruleForm.company"></td>
                            <td style="width:8%;line-height:28px;">油耗因子：</td>
                            <td style="width:15%;line-height:28px;">  <input class="sys-common-input" placeholder="请输入" v-model="ruleForm.company"></td>
                            <td style="width:8%;line-height:28px;">里程因子：</td>
                            <td style="width:15%;line-height:28px;">  <input class="sys-common-input" placeholder="请输入" v-model="ruleForm.company"></td>
                            <td style="width:8%;">每日行驶里程：</td>
                            <td style="width:15%;"><input class="sys-common-input" placeholder="请输入" v-model="ruleForm.company"></td>
                        </tr>
                        <tr>
                            <td style="width:8%;">每日行驶时间：</td>
                            <td style="width:15%;"><input class="sys-common-input" placeholder="请输入" v-model="ruleForm.company"></td>
                        </tr>
                    </table>
                      
                </form>
                
                
            </div>
        </div>
        
    </div>
</template>
<script>
  export default {
    data() {
      return {
        formInline: {
          user: '',
          region: ''
        },
         ruleForm: {
          name1: '',
          name2: '',
          name3: '',
          name4: '',
          
          name5: '',
          name6: '',
          name7: ''
        },
        rules: {
          name1: [
            { required: true, message: '请填写名称', trigger: 'blur' },
            { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
          ],
          name2: [
            { required: true, message: '请选择活动区域', trigger: 'change' }
          ],
          name3: [
            { required: true, message: '请选择活动区域', trigger: 'change' }
          ],
          name4: [
            {required: true, message: '请选择活动区域', trigger: 'change' }
          ],
          name5: [
            { required: true, message: '请选择活动区域', trigger: 'change' }
          ],
          name6: [
            { required: true, message: '请选择活动区域', trigger: 'change' }
          ],
          name7: [
            { required: true, message: '请选择活动区域', trigger: 'change' }
          ]
        }
      }
    },
    methods: {
      onSubmit() {
        console.log('submit!');
      }
    }
  }
</script>
<style>
    /* body{
        margin: 50px auto;
    } */

    /* el-form begin */
    .common-caredit-form .el-form{
        margin: 0px auto;
        width: 1150px;
        height: 140px;
        border-bottom: 1px solid rgba(238,238,238,1);
    }
    .el-input--mini .el-input__inner{
        box-shadow: 0px 0px 6px 0px rgba(25,107,255,0.1);
    }
    
</style>
