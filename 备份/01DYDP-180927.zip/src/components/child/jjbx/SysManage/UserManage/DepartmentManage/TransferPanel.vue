<!--   
    name：TransferPanel部门结构穿梭框面板组件
    desc：实现调整部门结构，以及调用部门下属车辆穿梭框组件
    param：paramName{param }        
    return Value : None
    author：wenls 
    date：2018.9.19
-->
<template>
    <div class="child-transferpanel-body">
        <!-- background: #f5f5f5; -->
        <div class="child-transferpanel-mainL">
            <div style="width: 100%;text-align: center;height: 30px;line-height: 30px;">部门架构</div>
            <div class="subResult fix">
                <div class="subResultTop ">
                    <div class="tOperate">
                        <a ref="addDept" @click="onAddDept()" title="添加子部门"><i class="el-icon-plus"></i></a>
                        <a @click="onEditDept();" title="修改部门"><i class="el-icon-edit"></i></a>
                        <a @click="onRemoveDept()" title="删除部门"><i class="el-icon-close"></i></a>
                        <!-- add dialog -->
                        <el-dialog title="添加部门" :visible.sync="addDialog.addDeptDialogVisible" width="40%" center>
                            <div style="width:100%;height:30px;line-height:30px;">
                                &nbsp;上级部门：
                                {{ checkedNode.label }}
                                <input type="text" v-model="addDialog.addDeptForm.parentId"/>
                            </div>
                            <div class="trans-el-dialog-row">
                                <span  >*</span>部门名称：
                                <input class="inp" type="text" placeholder="请输入部门名称" v-model="addDialog.addDeptForm.organName">
                            </div>
                            <div class="trans-el-dialog-row">
                                <span  >*</span>组织类型：
                                <input class="inp" type="text" placeholder="请输入部门名称" v-model="addDialog.addDeptForm.organType">
                            </div>
                            <div class="trans-el-dialog-row">
                                <span  >&nbsp;</span>领导名称：
                                <input class="inp" type="text" placeholder="请输入部门名称" v-model="addDialog.addDeptForm.leaderName">
                            </div>
                            <div class="trans-el-dialog-row">
                                <span  >&nbsp;</span>联系人：
                                <input class="inp" type="text" placeholder="请输入部门名称" v-model="addDialog.addDeptForm.organContact">
                            </div>
                            <div class="trans-el-dialog-row">
                                <span  >&nbsp;</span>组织logo：
                                <input class="inp" type="text" placeholder="请输入部门名称" v-model="addDialog.addDeptForm.organLogo">
                            </div>
                            <div class="trans-el-dialog-row">
                                <span  >&nbsp;</span>电话：
                                <input class="inp" type="text" placeholder="请输入部门名称" v-model="addDialog.addDeptForm.phone">
                            </div>
                            <div class="trans-el-dialog-row">
                                <span  >&nbsp;</span>备注：
                                <input class="inp" type="text" placeholder="请输入部门名称" v-model="addDialog.addDeptForm.remark">
                            </div>
                            <span slot="footer" class="dialog-footer">
                                <el-button size="mini" @click="addDialog.addDeptDialogVisible = false">取 消</el-button>
                                <el-button size="mini" type="primary" @click="addDeptAction()">确 定</el-button>
                            </span>
                        </el-dialog>
                        <!-- exid dialog -->
                        <el-dialog title="修改部门" :visible.sync="editDialog.editDeptDialogVisible" width="40%" center>

                            <div class="trans-el-dialog-row">
                                <span  >*</span>部门名称：
                                <input class="inp" type="text" placeholder="请输入部门名称" v-model="checkedData.label">
                            </div>
                            <div class="trans-el-dialog-row">
                                <span  >*</span>部门名称：
                                <input class="inp" type="text" placeholder="请输入部门名称" v-model="checkedData.label">
                            </div>
                            <div class="trans-el-dialog-row">
                                <span  >*</span>部门名称：
                                <input class="inp" type="text" placeholder="请输入部门名称" v-model="checkedData.label">
                            </div>
                            <div class="trans-el-dialog-row">
                                <span  >*</span>部门名称：
                                <input class="inp" type="text" placeholder="请输入部门名称" v-model="checkedData.label">
                            </div>
                            <div class="trans-el-dialog-row">
                                <span  >*</span>部门名称：
                                <input class="inp" type="text" placeholder="请输入部门名称" v-model="checkedData.label">
                            </div>
                            <span slot="footer" class="dialog-footer">
                                <el-button size="mini" @click="editDialog.editDeptDialogVisible = false">取 消</el-button>
                                <el-button size="mini" type="primary" @click="editDeptAction()">确 定</el-button>
                            </span>
                        </el-dialog>
                    </div>
                    <div class="comSearch ">
                        <input class="inp" type="text" placeholder="请输入部门" v-model="filterText">
                    </div>
                </div>
            </div>
            <div style="width:100%;height:calc( 100% - 70px );border: 1px solid #e7e7e7;border-top:0;">

                <el-tree ref="tree2" class="filter-tree" :data="deptData" :props="defaultProps" :expand-on-click-node="false"
                    :highlight-current="true" default-expand-all :filter-node-method="filterNode">
                    <span class="custom-tree-node" slot-scope="{ node, data }">
                        <span @click="() => setDeptData(node,data)">{{ node.label }}</span>
                    </span>
                </el-tree>
            </div>
        </div>
        <div style="float: left;box-sizing: content-box;
        width:65%;height:100%; 
        border-radius: 3px;color: #444;">
            <transfer-box></transfer-box>
        </div>

    </div>
</template>
<script>
    import ajax from "axios";
    import transferBox from "@/components/child/jjbx/SysManage/UserManage/DepartmentManage/TransferBox.vue";
    export default {
        components: {
            transferBox
        },
        props: {
            optionParam: {
                type: Object
            }
        },
        data() {
            return {
                checkedNode: "", //选中节点
                checkedData: "", //选中data
                addDialog: {
                    addDeptDialogVisible: false, //添加部门dialog显示开关 
                    addDeptForm: {
                        parentId:"",//父类ID
                        organName: "", //部门名称
                        organType:"",//组织类型（企业、政府）
                        leaderName:"",//领导名称
                        organContact:"",//联系人
                        organLogo:"",//组织logo 
                        phone:"",//电话
                        remark:"",//备注
                    }
                },
                editDialog: {
                    editDeptDialogVisible: false, //修改部门dialog显示开关 
                    editDeptForm: {
                        organName: "" //部门名称
                    }
                },
                filterText: "",
                deptData: [{
                    id: 1,
                    label: "恒通物流",
                    children: [{
                            id: 4,
                            label: "一点科技",
                            children: [{
                                    id: 9,
                                    label: "一点车队-1",
                                    children: []
                                },
                                {
                                    id: 10,
                                    label: "一点车队-2",
                                    children: []
                                }
                            ]
                        },
                        {
                            id: 2,
                            label: "通港物流",
                            children: [{
                                    id: 5,
                                    label: "通港车队-1",
                                    children: []
                                },
                                {
                                    id: 6,
                                    label: "通港车队-2",
                                    children: []
                                }
                            ]
                        },
                        {
                            id: 3,
                            label: "原油运输",
                            children: [{
                                    id: 7,
                                    label: "原油车队-1",
                                    children: []
                                },
                                {
                                    id: 8,
                                    label: "原油车队-2",
                                    children: []
                                }
                            ]
                        }
                    ]
                }],
                defaultProps: {
                    children: "children",
                    label: "label"
                }
            };
        },
        computed: {},
        mounted() {
            let _this = this;
            _this.$nextTick(function () {
                _this.initExec();
            });
        },
        methods: {
            initExec() {
                let _this = this;
                ajax.get(_this.global_.apiUrlJj + "/get/select-organ", {
                        id: 0
                    })
                    .then(function (res) {
                        console.log(res);
                        if (res.data.isSuccess) {
                            _this.deptData = res.data.data
                        } else {
                            _this.$message({
                                type: "error",
                                message: "部门机构数据获取失败!"
                            });
                        }
                    })
                    .catch(function (error) {
                        _this.$message({
                            type: "error",
                            message: "部门机构数据获取失败!"
                        });
                    });
            },
            filterNode(value, data) {
                if (!value) return true;
                return data.label.indexOf(value) !== -1;
            },
            //获取当前选中节点、数据包
            setDeptData(node, data) {
                console.log(data);
                let _this = this;
                _this.checkedData = data;
                _this.checkedNode = node;
                _this.addDialog.addDeptForm.parentId = data.id;
            },
            //删除部门
            onRemoveDept() {
                let _this = this;
                if (!_this.checkedData) {
                    this.$msgOpen(this, "提示", "请选择部门！", function (val) {
                        console.log(val);
                    });
                }
                this.$confirm("此操作将永久删除该部门, 是否继续?", "提示", {
                        confirmButtonText: "确定",
                        cancelButtonText: "取消",
                        type: "warning",
                        center: true
                    })
                    .then(() => {
                        const parent = _this.checkedNode.parent;
                        const children = parent.data.children || parent.data;
                        const index = children.findIndex(
                            d => d.id === _this.checkedData.id
                        );
                        children.splice(index, 1);
                        this.$message({
                            type: "success",
                            message: "删除成功!"
                        });
                    })
                    .catch(() => {
                        this.$message({
                            type: "info",
                            message: "已取消删除"
                        });
                    });
            },
            //添加部门
            onAddDept() {
                let _this = this;
                if (_this.checkedData) {
                    _this.addDialog.addDeptDialogVisible = true;
                } else {
                    this.$msgOpen(this, "提示", "请选择部门！", function (val) {
                        console.log(val);
                    });
                }
            },
            //添加部门action
            addDeptAction() {
                let _this = this;
                if (this.$trim(_this.addDialog.addDeptForm.organName) == "") {
                    this.$msgOpen(this, "提示", "请输入部门名称！", function (val) {
                        console.log(val);
                    });
                    return;
                }
                console.log(JSON.stringify(_this.addDialog));
                /* let newNodeId = _this.$objMaxVal(_this.deptData) + 1;
                const newChild = {
                    id: newNodeId,
                    label: _this.addDialog.addDeptForm.organName,
                    children: []
                };
                if (!_this.checkedData.children) {
                    this.$set(_this.checkedData, "children", []);
                }
                _this.checkedData.children.push(newChild);
                _this.addDialog.addDeptForm.organName = "";
                _this.addDialog.addDeptDialogVisible = false;

                this.$message({
                    type: "success",
                    message: "添加成功!"
                }); */
            },
            //修改部门
            onEditDept() {
                let _this = this;
                if (_this.checkedData) {
                    _this.editDialog.editDeptDialogVisible = true;
                } else {
                    this.$msgOpen(this, "提示", "请选择部门！", function (val) {
                        console.log(val);
                    });
                }
            },
            //修改部门action
            editDeptAction() {
                let _this = this;
                console.log(_this.checkedData);
                if (this.$trim(_this.checkedData.label) == "") {
                    this.$msgOpen(this, "提示", "请输入部门名称！", function (val) {
                        console.log(val);
                    });
                    return;
                }
                if (!_this.checkedData.children) {
                    this.$set(_this.checkedData, "children", []);
                }
                _this.editDialog.editDeptForm.organName = "";
                _this.editDialog.editDeptDialogVisible = false;
                console.log(_this.deptData);
                this.$message({
                    type: "success",
                    message: "修改成功!"
                });
            }

            /* addNode() {
                        let _this = this;
                        let currentNode = this.$refs.tree2.currentNode;
                        console.log(_this.$refs.tree2.getCheckedKeys());
                        if (currentNode) {
                            _this.checkedNode = currentNode.node;
                            console.log(_this.checkedNode);
                            _this.addDialog.addDeptDialogVisible = true;
                        } else {
                            this.$msgOpen(this, "提示", "请选择部门名称！", function (val) {
                                console.log(val);
                            });
                        }
                    },
                    addNodeAction() {
                        let _this = this;
                        let addNodeId = _this.$objMaxVal(_this.deptData) + 1;
                        _this.addDialog.addDeptDialogVisible = false;
                        console.log(_this.checkedNode.id);
                        let initExec = (o, parentId, param) => {
                            console.log(param);
                            let obj = o;
                            if (obj) {
                                obj.forEach((ele, i) => {
                                    if (typeof ele.children == "object") {
                                        if (ele.id === parentId) {
                                            if (ele.children) {
                                                ele.children.push(param);
                                            } else {
                                                ele.children = [param];
                                            }
                                        }
                                        initExec(ele.children, parentId, param);
                                    } else {
                                        if (ele.id === parentId) {
                                            if (ele.children) {
                                                ele.children.push(param);
                                            } else {
                                                ele.children = [param];
                                            }
                                        }
                                    }
                                });
                            }

                            return obj;
                        };
                        _this.deptData = initExec(
                            _this.deptData,
                            _this.checkedNode.id, {
                                id: addNodeId,
                                label: _this.addDialog.addDeptForm.organName
                            }
                        );
                        console.log(_this.deptData);
                    }, */
        },
        watch: {
            filterText(val) {
                this.$refs.tree2.filter(val);
            }
        },
        beforeDestroy() {}
    };

</script>
<style>
    .child-transferpanel-body {
        position: relative;
        width: 100%;
        min-width: 800px;
        height: 100%;
        background: #F8F8F8;
    }

    .child-transferpanel-body .child-transferpanel-mainL {
        float: left;
        width: 33%;
        height: 100%;
        margin-left: 10px;
        background: #f5f5f5;
        /* border-radius: 3px; */
        color: #444;
    }

    .child-transferpanel-mainL .subResult {
        position: relative;
        /* border-radius: 3px; */
        width: 100%;
        border: 1px solid #e7e7e7;
    }

    .subResult .subResultTop {
        height: 32px;
        /* border-radius: 3px 3px 0 0;
        border-bottom: 1px solid #dddddd; */
        background: #ffffff;
    }

    .subResult .fix {
        content: ".";
        display: block;
        clear: both;
        visibility: hidden;
        height: 0px;
    }

    .subResult .tOperate {
        float: left;
    }

    .tOperate i {
        display: block;
        width: 15px;
        height: 15px;
    }

    .tOperate a {
        display: inline-block;
        border-radius: 3px;
        padding: 3px;
        margin: 6px 0 0 5px;
    }

    .tOperate a:hover {
        background: #fff;
        box-shadow: 0 0 3px #adadad;
    }

    .subResultTop .comSearch {
        float: right;
        margin: 2px 5px 0 0;
        height: 25px;
        border-radius: 3px;
        border: 1px solid #e4e4e4;
        background-color: #ffffff;
    }

    .comSearch .inp {
        float: left;
        width: 110px;
        height: 25px;
        line-height: 25px;
        padding-left: 3px;
        color: #c0c0c0;
        outline: none;
        border: 0;
        background: none;
        font-family: Microsoft YaHei;
    }

    .comSearch .botOver {
        /*  float: right;
        width: 15px;
        height: 15px;  
        cursor: pointer;
        margin: 5px 5px 0 0;
         overflow: hidden;
        outline: none;
        border: 0;
        background: none;
        font-family: Microsoft YaHei; */
    }

    .comSearch .bot {
        /*  float: right;
        width: 15px;
        height: 15px;  
        cursor: pointer;
        margin: 5px 5px 0 0;
         overflow: hidden;
        outline: none;
        border: 0;
        background: none;
        font-family: Microsoft YaHei; */
    }

    .trans-el-dialog-row {
        width: 100%;
        height: 30px;
        line-height: 30px;
    }
    .trans-el-dialog-row span{
        color: red;
    }
</style>
