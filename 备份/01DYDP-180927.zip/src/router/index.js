import Vue from 'vue'
import Router from 'vue-router'
// import HelloWorld from '@/components/HelloWorld'
// import { resolve } from 'dns';

Vue.use(Router)

export default new Router({
    mode: "history",
    fallback:false,
//     base: "/jjbx/",
    routes: [ 
        {
            path:'/login',
            component: resolve => require(['../components/page/Login.vue'], resolve) 
        }, {
            path: '/dydp/',  
            redirect:'/dydp/main'
        },
        {
            path:'/403',
            component: resolve => require(['../components/page/403.vue'], resolve),
            meta: { title: '403' }
        },
        {
            path:'/404',
            component: resolve => require(['../components/page/404.vue'], resolve),
            meta: { title: '404' }
        },
        {
            path: '/', 
            redirect:'/main'
        }, 
        {
            path: '/',
            component: resolve => require(['../components/common/Home.vue'],resolve),
            meta:{
                title:'一点科技'
            },
            children:[
                /* 东营大屏 */
                {
                    path:'/dydp/main',
                    name:'dy_main',
                    component: resolve => require(['../components/page/dydp/Main.vue'], resolve),
                    meta: { title: '东营大屏' }
                },     
                /* 紧急避险 */
                {
                    path:'/main',
                    name:'jj_main',
                    component: resolve => require(['../components/page/jjbx/Main.vue'], resolve),
                    meta: { title: '紧急避险' }
                },           
                /* 系统管理 */
                /* 系统管理-->用户管理 */
                {
                    path:'/jjbx/SysManage/dept/deptMain',
                    name:'sm_dept_deptMain',
                    component: resolve => require(['../components/page/jjbx/SysManage/UserManage/DepartmentManage/DepartmentMain.vue'], resolve),
                    meta: { title: '部门档案' }
                },


                /* 系统管理-->车辆管理 */
                /* 系统管理-->车辆管理-->主车档案 */
                {
                    path:'/jjbx/SysManage/vehicle/vehicle',
                    name:'sm_vehicle_vehicle',
                    component: resolve => require(['../components/page/jjbx/SysManage/VehicleManage/vehicle/vehicle.vue'], resolve),
                    meta: { title: '主车档案' }
                },
                {
                    path:'/jjbx/SysManage/vehicle/CarEdit',
                    name:'sm_vehicle_carEdit',
                    component: resolve => require(['../components/page/jjbx/SysManage/VehicleManage/vehicle/CarEdit.vue'], resolve),
                    meta: { title: '主车编辑' }
                },
                {
                    path:'/jjbx/SysManage/vehicle/CarDetails',
                    name:'sm_vehicle_CarDetails',
                    component: resolve => require(['../components/page/jjbx/SysManage/VehicleManage/vehicle/CarDetails.vue'], resolve),
                    meta: { title: '主车详细信息' }
                },
                /* 系统管理-->人员管理 */
                /* 系统管理-->人员管理-->驾驶员档案 */
                {
                    path:'/jjbx/SysManage/driver/driverMain',
                    name:'sm_driver_driver',
                    component: resolve => require(['../components/page/jjbx/SysManage/PeopleManage/driver/Driver.vue'], resolve),
                    meta: { title: '驾驶员档案' }
                },
                {
                    path:'/jjbx/SysManage/driver/driverDetails',
                    name:'sm_driver__driverDetails',
                    component: resolve => require(['../components/page/jjbx/SysManage/PeopleManage/driver/DriverDetails.vue'], resolve),
                    meta: { title: '驾驶员详细信息' }
                },
                {
                    path:'/jjbx/sysManage/driver/addDriver',
                    name:'sm_driver__addDriver',
                    component: resolve => require(['../components/page/jjbx/SysManage/PeopleManage/driver/DriverAdd.vue'], resolve),
                    meta: { title: '添加驾驶员' }
                },                
                /* 系统管理-->设备管理 */

                
                /* 系统管理-->系统配置 */


                /* 财务中心 */
                /* 报表中心 */
                /* 监控中心 */
                {
                    path:'/jjbx/MntManage/Map/Monit',
                    name:'mm_map__monit',
                    component: resolve => require(['../components/page/jjbx/MonitorManage/RealtimeMonitor/RealtimeMonitor.vue'], resolve),
                    meta: { title: '实时定位' }
                },
               /*  { 
                    path:'/jjbx/MntManage/Map/Track',
                    name:'mm_map__track',
                    component: resolve => require(['../components/page/jjbx/MonitorManage/RealtimeMonitor/RealtimeMonitor.vue'], resolve),
                    meta: { title: '实时定位' }
                }, */
                {
                    path:'/permission',
                    component: resolve => require(['../components/page/Permission.vue'], resolve),
                    meta: { title: '权限测试',permission:true }
                }
            ]
        },
        {
            path: '*',
            redirect: '/404'
        }
    ]
})
