<template>
  <div id="app"> 
    <router-view/>
  </div>
</template>
 <style > 
    @import "../static/css/color-dark.css";     /*深色主题*/
    @import "../static/css/main.css";
 </style>