 
    const apiUrlDy =  'http://47.105.126.92:18185'; //http://47.105.126.92:18182  东营大屏
    const apiUrlJj =  'http://192.168.80.184:8088'; //  紧急避险  

    export default {    
        apiUrlDy,
        apiUrlJj 
    } 
