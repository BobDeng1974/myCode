<!--   
    name：紧急避险角色管理
    desc：紧急避险主界面
    param：None        
    return Value : None
    author：qiaoyh
    date：2018.9.3
-->
<template>

    <div class="common-veh-body" style="margin-left:10px;margin-top:8px;font-family: PingFang-SC-Bold;">
        <div style="width:100%;background-color:#F8F8F8;">
            <div class="handle-box">

                <el-form :inline="true" :model="formInline" class="demo-form-inline" size="mini" style="padding-top:0.5%;">
                    <el-form-item label="云通智安" style="margin-right:-60px;">
                        <el-select v-model="formInline.region" placeholder="活动区域" style="width:60%;">
                            <el-option label="区域一" value="shanghai"></el-option>
                            <el-option label="区域二" value="beijing"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="活动区域" style="margin-right:-50px;">
                        <el-select v-model="formInline.region" placeholder="活动区域" style="width:60%;">
                            <el-option label="区域一" value="shanghai"></el-option>
                            <el-option label="区域二" value="beijing"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="活动区域" style="margin-right:-50px;">
                        <el-select v-model="formInline.region" placeholder="活动区域" style="width:60%;">
                            <el-option label="区域一" value="shanghai"></el-option>
                            <el-option label="区域二" value="beijing"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="活动区域" style="margin-right:-50px;">
                        <el-select v-model="formInline.region" placeholder="活动区域" style="width:60%;">
                            <el-option label="区域一" value="shanghai"></el-option>
                            <el-option label="区域二" value="beijing"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="活动区域" style="margin-right:-50px;">
                        <el-select v-model="formInline.region" placeholder="活动区域" style="width:60%;">
                            <el-option label="区域一" value="shanghai"></el-option>
                            <el-option label="区域二" value="beijing"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item style="float:right;">
                        <el-button type="primary">查询</el-button>
                    </el-form-item>
                </el-form>
            </div>
        </div>
        <div style="height:50px;width:98%;background-color:#FFFFFF;">
            <div style=" width:422px;float:right;margin-top:5px;margin-left: 1400px;">
                <el-button class="el-icon-check" type="primary" plain size="small" style="float:left;">导出</el-button>
                <el-button class="el-icon-plus" type="primary" plain size="small" style="float:left;">添加</el-button>
                <el-button class="el-icon-delete" type="primary" plain size="small" style="float:left;">批量设置百公里油耗</el-button>
                <el-button class="el-icon-delete" type="primary" plain size="small" style="float:left;">表格列设置</el-button>
            </div>
        </div>
        <div style="width:98%;">
            <el-table class="el-table__body" ref="multipleTable" :data="tableData" stripe height="650" tooltip-effect="dark"
                style="width: 100%;header-align:center;" max-height="650" :header-cell-style="{background:'rgba(238,245,251,1)'}"
                @cell-mouse-enter="handleMouseEnter" @cell-mouse-leave="handleMouseOut">
                <el-table-column type="index" label="序号" width="60" align="center" style="background-color:#E4ECF7;">
                </el-table-column>
                <el-table-column prop="operation" label="操作" width="100" align="center">
                    <template slot-scope="{row,$index}">
                        <!-- <img src="../../../../static/img/jjbx/menu/bj2.png" style="display:inline-block;width:11px;height:15px;">
                        &nbsp;&nbsp;
                        <img src="../../../../static/img/jjbx/menu/bj2.png" style="display:inline-block;width:11px;height:15px;">
                        <img v-show="!ok[$index]" src="../../../../static/img/jjbx/menu/bj3.png" style="display:inline-block;width:11px;height:15px;">
                        &nbsp;&nbsp; -->
                        <img src="../../../../static/img/jjbx/menu/sc2.png" style="display:inline-block;width:11px;height:15px;">
                    </template>
                </el-table-column>
                <el-table-column prop="car_num" label="车编号" width="80" align="center" :show-overflow-tooltip="true">
                </el-table-column>
                <el-table-column prop="org_name" label="所属机构" align="center" :show-overflow-tooltip="true">
                </el-table-column>
                <el-table-column prop="length" label="车长" width="70" align="center">
                </el-table-column>
                <el-table-column prop="carriagetype" label="箱型" width="60" align="center">
                </el-table-column>
                <el-table-column prop="volume" label="额定体积" width="80" align="center">
                </el-table-column>
                <el-table-column prop="weight" label="额定载重" width="80" align="center">
                </el-table-column>

                <el-table-column prop="driver1" label="第一司机" width="80" align="center">
                </el-table-column>
                <el-table-column prop="driver1_tel" label="第一司机电话" width="100" align="center">
                </el-table-column>

                <el-table-column prop="gpsno" label="GPS设备编号" align="center">
                </el-table-column>

                <el-table-column prop="carriage_len" label="车厢长度" width="80" align="center">
                </el-table-column>
                <el-table-column prop="carriage_width" label="车厢宽" width="70" align="center">
                </el-table-column>
                <el-table-column prop="carriage_height" label="车型高" width="70" align="center">
                </el-table-column>

                <el-table-column prop="com_num" label="企业号" width="70" align="center">
                </el-table-column>
                <el-table-column prop="capacity" label="核载人数" width="80" align="center">
                </el-table-column>

                <el-table-column prop="gpsdevice_id" label="设备号" width="70" align="center">
                </el-table-column>
            </el-table>
            <div class="pagination">
                <el-pagination layout="prev, pager, next" :total="1000">
                </el-pagination>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                // ok:[],
                // multipleSelection: [],
                tableData: [{
                        car_num: "鲁F34990",
                        org_name: "权限小一点的管理员"
                    },
                    {
                        car_num: "鲁F34990",
                        org_name: "北方陆港"
                    },
                    {
                        car_num: "鲁F34990",
                        org_name: "xxx"
                    },
                    {
                        car_num: "鲁F34990",
                        org_name: "天津运营"
                    },
                    {
                        car_num: "鲁F34990",
                        org_name: "运营商"
                    },
                    {
                        car_num: "鲁F34990",
                        org_name: "同城内部测试"
                    },
                    {
                        car_num: "鲁F34990",
                        org_name: "仓库管理员"
                    },
                    {
                        car_num: "鲁F34990",
                        org_name: "用户管理员"
                    },
                    {
                        car_num: "鲁F34990",
                        org_name: "系统管理员"
                    }
                ],

                formInline: {
                    user: "",
                    region: ""
                }
            };
        },
        methods: {
            // toggleSelection(rows) {
            //   if (rows) {
            //     rows.forEach(row => {
            //       this.$refs.multipleTable.toggleRowSelection(row);
            //     });
            //   } else {
            //     this.$refs.multipleTable.clearSelection();
            //   }
            // },
            // handleSelectionChange(val) {
            //   this.multipleSelection = val;
            // },
            // onSubmit() {
            //   console.log("submit!");
            // },
            handleMouseEnter: function (row, index) {
                // cell.children[2].children[3].style.bgColor="red";
                //   console.log(1111111111);
                // let _this = this;
                // this.ok[index]=true;
            },
            handleMouseOut: function (row, index) {
                //   cell.children[0].children[1].style.color="#ffffff";
                //   console.log(222222222);
                // let _this = this;
                // this.ok[index]=false;
            }
        }
    };

</script>
<style> 
    .common-veh-body .el-table__body {
        /* margin-top: 10px; */
        border-radius: 4px !important;
    }

    .common-veh-body .el-table__body tr {
        height: 35px !important;
    }

    .common-veh-body .el-table td,
    .el-table th {
        padding: 2px !important;
    }

    .common-veh-body .icon {
        width: 2em !important;
        height: 2em !important;
        color: #5eaee3 !important;
    }

    .common-veh-body .handle-box {
        /* margin-bottom: 20px; */
        width: 97.4% !important;
        height: 50px !important;
        line-height: 50px !important;
        padding-left: 1.2% !important;
        font-size: 14px !important;
    }

    .common-veh-body .handle-select {
        width: 8.4% !important;
        height: 32px !important;
        margin: 0 8px !important;
    }

    .common-veh-body .handle-input {
        width: 280px !important;
        display: inline-block !important;
    }

    .common-veh-body .el-table--striped .el-table__body tr.el-table__row--striped td {
        background: #f0f8ff !important;
    }

    .common-veh-body .el-input--small .el-input__inner {
        height: 32px !important;
        line-height: 32px !important;
    }

    .common-veh-body .el-input__inner {
        box-shadow: 0px 0px 6px 0px rgba(25, 107, 255, 0.1) !important;
    }

    .common-veh-body .el-input--suffix .el-input__inner {
        padding-right: 10px !important;
    }

    .common-veh-body .el-table th>.cell {
        font-size: 14px !important; 
        font-weight: 700 !important;
        color: rgba(30, 30, 30, 1) !important;
    }

    .common-veh-body .el-table .cell {
        font-size: 12px !important; 
        /* font-weight: bold;  */
        /* color: rgba(144, 144, 144, 1); */
    }

    /* .el-table .cell:hover{
        color: rgba(255,255,255,1);
    } */
    /* .el-table--enable-row-hover .el-table__body tr:hover > td {
  background-color: #2F95F4 !important;
  color:rgba(255,255,255,1) !important;
} */

</style>
