<!--   
    name：紧急避险角色管理
    desc：紧急避险主界面
    param：None        
    return Value : None
    author：qiaoyh
    date：2018.9.3
-->
<template>

    <div class="common-veh-body" style="margin-left:10px;margin-top:8px;">
        <div style="width:100%;background-color:#F8F8F8;">
            <div class="handle-box">

                <el-form :inline="true" :model="formInline" class="demo-form-inline" size="mini" style="padding-top:0.5%;">
                    <el-form-item label="云通智安" style="margin-right:-60px;">
                        <el-select v-model="formInline.region" placeholder="活动区域" style="width:60%;">
                            <el-option label="区域一" value="shanghai"></el-option>
                            <el-option label="区域二" value="beijing"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="活动区域" style="margin-right:-50px;">
                        <el-select v-model="formInline.region" placeholder="活动区域" style="width:60%;">
                            <el-option label="区域一" value="shanghai"></el-option>
                            <el-option label="区域二" value="beijing"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="活动区域" style="margin-right:-50px;">
                        <el-select v-model="formInline.region" placeholder="活动区域" style="width:60%;">
                            <el-option label="区域一" value="shanghai"></el-option>
                            <el-option label="区域二" value="beijing"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="活动区域" style="margin-right:-50px;">
                        <el-select v-model="formInline.region" placeholder="活动区域" style="width:60%;">
                            <el-option label="区域一" value="shanghai"></el-option>
                            <el-option label="区域二" value="beijing"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="活动区域" style="margin-right:-50px;">
                        <el-select v-model="formInline.region" placeholder="活动区域" style="width:60%;">
                            <el-option label="区域一" value="shanghai"></el-option>
                            <el-option label="区域二" value="beijing"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item style="float:right;">
                        <el-button type="primary">查询</el-button>
                    </el-form-item>
                </el-form>
            </div>
        </div>
        <div style="height:50px;width:98%;background-color:#FFFFFF;">
            <div style=" width:422px;float:right;margin-top:5px;margin-left: 1400px;">
                <el-button class="el-icon-check" type="primary" plain size="small" style="float:left;">导出</el-button>
                <el-button class="el-icon-plus" type="primary" plain size="small" style="float:left;">添加</el-button>
                <el-button class="el-icon-delete" type="primary" plain size="small" style="float:left;">批量设置百公里油耗</el-button>
                <el-button class="el-icon-delete" type="primary" plain size="small" style="float:left;">表格列设置</el-button>
            </div>
        </div>
        <div class="common-veh-table" style="width:98%;">
            <el-table :data="tableData" :highlight-current-row="true" :stripe="true" :header-cell-style="{background:'rgba(238,245,251,1)'}"
                style="width: 100%;border:1px solid rgba(237,241,245,1); " height="250" :row-class-name="onSetRowIndex"
                @cell-mouse-enter="handleMouseEnter" @cell-mouse-leave="handleMouseOut">
                <el-table-column fixed align="center" type="index" :index="indexMethod" label="序号" width="100">
                </el-table-column>  
                <el-table-column prop="name" align="center" label="详情" width="100">
                    <template slot-scope="scope">
                        <img v-if="scope.row.isSele" src="../../../../../static/img/jjbx/vehicle/xq.png" style=" width:11px;height:15px;vertical-align: middle;">
                        <img v-if="!scope.row.isSele" src="../../../../../static/img/jjbx/vehicle/xq.png" style=" width:11px;height:15px;vertical-align: middle;">
                    </template>
                </el-table-column>
                <el-table-column prop="province" align="center" label="操作" width="100">
                    <template slot-scope="scope">
                        <img v-if="scope.row.isSele" src="../../../../../static/img/jjbx/vehicle/bj.png" style=" width:11px;height:15px;vertical-align: middle;margin-right:14px;">
                        <img v-if="!scope.row.isSele" src="../../../../../static/img/jjbx/vehicle/bj2.png" style=" width:11px;height:15px;vertical-align: middle;margin-right:14px;">                         
                        <img v-if="scope.row.isSele" src="../../../../../static/img/jjbx/vehicle/sc.png" style=" width:11px;height:15px;vertical-align: middle;">
                        <img v-if="!scope.row.isSele" src="../../../../../static/img/jjbx/vehicle/sc2.png" style=" width:11px;height:15px;vertical-align: middle;">
                    </template>
                </el-table-column>
                <el-table-column prop="city" align="center" label="车编号" width="120">
                </el-table-column>
                <el-table-column prop="address" align="center" label="所属机构" width="150">
                </el-table-column>
                <el-table-column prop="zip" align="center" label="车长" width="120">
                </el-table-column>
                <el-table-column prop="zip" align="center" label="箱型" width="120">
                </el-table-column>
                <el-table-column prop="zip" align="center" label="额定体积" width="120">
                </el-table-column>
                <el-table-column prop="zip" align="center" label="额定载重" width="120">
                </el-table-column>
            </el-table>
            <div class="pagination">
                <el-pagination layout="prev, pager, next" :total="1000">
                </el-pagination>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                // ok:[],
                // multipleSelection: [],
                tableData: [{
                        date: "1",
                        isSele: false,
                        name: "王小虎",
                        province: "上海",
                        city: "鲁F123",
                        address: "恒通集团",
                        zip: "111"
                    },
                    {
                        date: "1",
                        isSele: false,
                        name: "王小虎",
                        province: "上海",
                        city: "鲁F123",
                        address: "恒通集团",
                        zip: "111"
                    },
                    {
                        date: "1",
                        isSele: false,
                        name: "王小虎",
                        province: "上海",
                        city: "鲁F123",
                        address: "恒通集团",
                        zip: "111"
                    },
                    {
                        date: "1",
                        isSele: false,
                        name: "王小虎",
                        province: "上海",
                        city: "鲁F123",
                        address: "恒通集团",
                        zip: "111"
                    },
                    {
                        date: "1",
                        isSele: false,
                        name: "王小虎",
                        province: "上海",
                        city: "鲁F123",
                        address: "恒通集团",
                        zip: "111"
                    },
                    {
                        date: "1",
                        isSele: false,
                        name: "王小虎",
                        province: "上海",
                        city: "鲁F123",
                        address: "恒通集团",
                        zip: "111"
                    },
                    {
                        date: "1",
                        isSele: false,
                        name: "王小虎",
                        province: "上海",
                        city: "鲁F123",
                        address: "恒通集团",
                        zip: "111"
                    }
                ],

                formInline: {
                    user: "",
                    region: ""
                }
            };
        },
        methods: {
            indexMethod(index) {
                return index + 1;
            },
            onSetRowIndex({
                row,
                rowIndex
            }) {
                //把每一行的索引放进row 
                row.index = rowIndex;
            },
            handleMouseEnter: function (row, event, column) {
                var index = row.index;
                this.tableData[row.index].isSele = true;
            },
            handleMouseOut: function (row, event, column) {
                this.tableData[row.index].isSele = false;
            }
        }
    };

</script>
<style>
    /* 设置滚动条的样式 */
     scrollbar-base-color{
        width: 5px; 
        
        background: #E7EAEE
    }
 
 
    .common-veh-table{
		/*scrollbar-arrow-color: #f4ae21; *//*三角箭头的颜色*/ 
		 /*scrollbar-face-color: #333;*//*立体滚动条的颜色*/ 
		/*scrollbar-3dlight-color: #666; *//*立体滚动条亮边的颜色*/ 
		/*scrollbar-highlight-color: #666; *//*滚动条空白部分的颜色*/ 
		/*scrollbar-shadow-color: #999; *//*立体滚动条阴影的颜色*/ 
		/*scrollbar-darkshadow-color: #666; *//*立体滚动条强阴影的颜色*/ 
		/*scrollbar-track-color: #666; *//*立体滚动条背景颜色*/ 
		/*scrollbar-base-color:#f8f8f8; *//*滚动条的基本颜色*/ 
	}
    /*定义滚动条的轨道颜色、内阴影及圆角*/
    .common-veh-table ::-webkit-scrollbar-track { 
        background-color: #E7EAEE; 
    }

    /*定义滑块颜色、内阴影及圆角*/
    .common-veh-table ::-webkit-scrollbar-thumb {
        border-radius: 17px;
        -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, .3);
        background-color: #fff;
    }

    /*定义两端按钮的样式*/
    .common-veh-table ::-webkit-scrollbar-button {
        background-color: #E7EAEE;
    }

    /*定义右下角汇合处的样式*/
    .common-veh-table ::-webkit-scrollbar-corner {
        background:#E7EAEE;
    }


    .common-veh-body .el-table__body {
        /* margin-top: 10px; */
        border-radius: 4px !important;
    }

    .common-veh-body .el-table__body tr {
        height: 35px !important;
    }

    .common-veh-body .el-table td,
    .el-table th {
        padding: 2px !important;
    }

    .common-veh-body .icon {
        width: 2em !important;
        height: 2em !important;
        color: #5eaee3 !important;
    }

    .common-veh-body .handle-box {
        /* margin-bottom: 20px; */
        width: 97.4% !important;
        height: 50px !important;
        line-height: 50px !important;
        padding-left: 1.2% !important;
        font-size: 14px !important;
    }

    .common-veh-body .handle-select {
        width: 8.4% !important;
        height: 32px !important;
        margin: 0 8px !important;
    }

    .common-veh-body .handle-input {
        width: 280px !important;
        display: inline-block !important;
    }

    .common-veh-body .el-input--small .el-input__inner {
        height: 32px !important;
        line-height: 32px !important;
    }

    .common-veh-body .el-input__inner {
        box-shadow: 0px 0px 6px 0px rgba(25, 107, 255, 0.1) !important;
    }

    .common-veh-body .el-input--suffix .el-input__inner {
        padding-right: 10px !important;
    }

    .common-veh-body .el-table  { 
        color: #909090 !important;
    }
    .common-veh-body .el-table th>.cell {
        font-size: 14px !important; 
        font-weight: 700 !important;
        color: rgba(30, 30, 30, 1) !important;
    }

    .common-veh-body .el-table .cell {
        font-size: 12px !important; 
    }

    .common-veh-body .el-table__body tr.hover-row>td {
        background: #2f95f4 !important;
        color: #fff;
    }

    .common-veh-body .el-table--striped .el-table__body tr.el-table__row--striped td {
        background: #f6f8f9;
    }
 

</style>
