import Vue from 'vue'
import Router from 'vue-router'
// import HelloWorld from '@/components/HelloWorld'
// import { resolve } from 'dns';

Vue.use(Router)

export default new Router({
    mode: "history",
    fallback:false,
//     base: "/jjbx/",
    routes: [ 
        {
            path:'/login',
            component: resolve => require(['../components/page/Login.vue'], resolve) 
        }, {
            path: '/dydp/',  
            redirect:'/dydp/main'
        },,
        {
            path:'/403',
            component: resolve => require(['../components/page/403.vue'], resolve),
            meta: { title: '403' }
        },
        {
            path:'/404',
            component: resolve => require(['../components/page/404.vue'], resolve),
            meta: { title: '404' }
        },
    /*     {
            path: '/dydp/', 
            component: resolve => require(['../components/page/dydp/Main.vue'], resolve),
            // redirect:'/main'
        }, */
        {
            path: '/', 
            redirect:'/main'
        }, 
        {
            path: '/',
            component: resolve => require(['../components/common/Home.vue'],resolve),
            meta:{
                title:'一点科技'
            },
            children:[
                {
                    path:'/main',
                    component: resolve => require(['../components/page/jjbx/Main.vue'], resolve),
                    meta: { title: '紧急避险' }
                },
                {
                    path:'/dydp/main',
                    component: resolve => require(['../components/page/dydp/Main.vue'], resolve),
                    meta: { title: '东营大屏' }
                },
                {
                    path:'/vehicle',
                    component: resolve => require(['../components/page/jjbx/vehicle/vehicle.vue'], resolve),
                    meta: { title: '车辆预警' }
                },
                {
                    path:'/monitor',
                    component: resolve => require(['../components/page/jjbx/vehicle/RealtimeMonitor.vue'], resolve),
                    meta: { title: '车辆预警' }
                },
                {
                    path:'/permission',
                    component: resolve => require(['../components/page/Permission.vue'], resolve),
                    meta: { title: '权限测试',permission:true }
                }
            ]
        },
        {
            path: '*',
            redirect: '/404'
        }
    ]
})
